#!/usr/bin/env python
# coding: utf-8

# In[2]:


data.describe()


# In[8]:


import pandas as pd
import numpy as np
#from sklearn.preprocessing import impute.SimpleImputer
#from sklearn.preprocessing import MinMaxScaler
fieldsused=['Age', 'Grade', 'Radiationsequencewithsurgery', 'Numberofprimaries', 'SurvivalTime', 'TumorSize', 'Radiation',
       'BehaviorcodeICD.O.3', 'Yearofdiagnosis',
       'PrimarySite', 'HistologicTypeICD.O.3',
       'Firstmalignantprimaryindicator', 'Sequencenumber', 'ICD.O.3Hist.behavmalignant',
       'RXSumm..ScopeRegLNSur.2003..', 'RXSumm..SurgPrimSite.1998..',
       'Reasonnocancer.directedsurgery', 'SurvivalTimeClass',
       'Metastasis']
fieldsused1=[
       'T', 'N','SurvivalTime', 'TumorSize', 'PrimarySite.labeled',
       'PrimarySite',
       'CSlymphnodes.2004..',
        'RXSumm..SurgOthReg.Dis.2003..',
       'RXSumm..ScopeRegLNSur.2003..', 'RXSumm..SurgPrimSite.1998..',
       'Reasonnocancer.directedsurgery', 'DerivedSS1977','SurvivalTimeClass','Metastasis']
data = pd.read_csv('/home/vedanth/Downloads/lung-cancer-metastasis-prediction-master/data/LungCancerDataset_AllRecords_NORM_reduced_features.csv',usecols=fieldsused1)
print(data.head())


# In[9]:


# Convert the DataFrame object into NumPy array otherwise you will not be able to impute
normalizedData = data.values


# In[10]:


#X = normalizedData[:,0:27]
#Y = normalizedData[:,27]
from sklearn import model_selection
from sklearn.ensemble import AdaBoostClassifier
seed = 7
num_trees = 70
'''
kfold = model_selection.KFold(n_splits=10, random_state=seed)
model = AdaBoostClassifier(n_estimators=num_trees, random_state=seed)
results = model_selection.cross_val_score(model, X, Y, cv=kfold)
print(results.mean())
'''


# In[11]:


labels= np.array(data['Metastasis'])
features= data.drop('Metastasis',axis=1)
feature_list= list(features.columns)
features= np.array(features)
print(features)


# In[12]:


from sklearn.model_selection import train_test_split
# Split the data into training and testing sets
train_features, test_features, train_labels, test_labels = train_test_split(features, labels, test_size = 0.25, random_state = 42)


# In[7]:


print('Training Features Shape:', train_features.shape)
print('Training Labels Shape:', train_labels.shape)
print('Testing Features Shape:', test_features.shape)
print('Testing Labels Shape:', test_labels.shape)


# In[13]:


model = AdaBoostClassifier(n_estimators=num_trees, random_state=seed)
model.fit(train_features, train_labels);
predictions = model.predict(test_features)
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
import pylab as pl

print('Train Accuracy:', accuracy_score(train_labels,model.predict(train_features))*100,'%')

print('Test Accuracy: ', accuracy_score(test_labels,predictions)*100,'%')


# In[ ]:





# In[ ]:




