#!/usr/bin/env python3.5
#import numpy
import sys
print(sys.path)