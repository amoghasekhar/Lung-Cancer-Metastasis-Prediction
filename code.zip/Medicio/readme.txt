main page-index.html
metastasis detection-metastasis.html,metastasis.php,normalize.py metastasisrandomforest.py
survivaltime prediction-survivaltime.html,survivaltime.php,normalizeST.py,survivaltimeadaboost.py
analysis- analysis.html, amd images



