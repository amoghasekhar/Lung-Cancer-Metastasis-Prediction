<?php
//test_echo();
$myArray = array();

$T = $_POST["T"];

  //$T=$_POST["T"];
 $N=$_POST["N"];
 $SurvivalTime=$_POST["SurvivalTime"];
 $TumorSize=$_POST["TumorSize"];
 // $PrimarySitelabeled=$_POST["PrimarySite.labeled"]
 $PrimarySite=$_POST["PrimarySite"];
 $CSlymphnodes2004=$_POST["lymphnodes"];
 $RXSummSurgOthRegDis2003=$_POST["RX1"];
 $RXSummScopeRegLNSur2003=$_POST["RX2"];
 $RXSummSurgPrimSite1998=$_POST["RX3"];
 $Reasonnocancerdirectedsurgery=$_POST["SurgeryDetails"];
 $DerivedSS1977=$_POST["DerivedSS1977"];
 // $SurvivalClass=$_POST["Survival Class"]
 array_push($myArray, $T,$N);
 array_push($myArray, $SurvivalTime, $TumorSize);
 array_push($myArray, $PrimarySite,$CSlymphnodes2004);
 array_push($myArray, $RXSummSurgOthRegDis2003,$RXSummScopeRegLNSur2003);
 array_push($myArray,  $RXSummSurgPrimSite1998,$Reasonnocancerdirectedsurgery);
 array_push($myArray,$DerivedSS1977);
 $file = fopen("/home/vedanth/courseMaster.csv","w");

foreach ($myArray as $myline)
  {
  fputcsv($file,explode(',',$myline));
  }
fclose($file);       
 //exec ( "/var/www/html/Medicio/MetastasisRandomForest.py $T $N " );
 //$command = escapeshellcmd('/var/www/html/Medicio/MetastasisRandomForest.py $T $N ');
//$output = shell_exec(" python3 /var/www/html/Medicio/test.py '$T' '$N' '$SurvivalTime' '$TumorSize' '$PrimarySite' '$CSlymphnodes2004' '$RXSummSurgOthRegDis2003' '$RXSummScopeRegLNSur2003' '$RXSummSurgPrimSite1998' '$Reasonnocancerdirectedsurgery' '$DerivedSS1977' ");
 //$output = shell_exec("python3 /var/www/html/Medicio/normalize.py '$T' '$N' ");
//putenv('PYTHONPATH=/usr/local/lib/python3.5/dist-packages');
#exec('/var/www/html/Medicio/test.py',$output,$ret);
$output = shell_exec(" python3 /var/www/html/Medicio/normalizeLog.py '$T' '$N' '$SurvivalTime' '$TumorSize' '$PrimarySite' '$CSlymphnodes2004' '$RXSummSurgOthRegDis2003' '$RXSummScopeRegLNSur2003' '$RXSummSurgPrimSite1998' '$Reasonnocancerdirectedsurgery' '$DerivedSS1977' ");
echo $output;
//$output2 = shell_exec(" python3 /var/www/html/Medicio/MetastasisRandomForestLog.py '$T' '$N' '$SurvivalTime' '$TumorSize' '$PrimarySite' '$CSlymphnodes2004' '$RXSummSurgOthRegDis2003' '$RXSummScopeRegLNSur2003' '$RXSummSurgPrimSite1998' '$Reasonnocancerdirectedsurgery' '$DerivedSS1977' ");
//var_dump($output);
//echo $output2;
 foreach ($output as $myline)
  {
  fputcsv($file,explode(',',$myline));
  }
fclose($file);
 //echo gettype($T);
 //print_r($myArray);
   //$path='/usr/bin/python3';
   //$python='/var/www/html/Medicio/MetastasisRandomForest.py';
   //$cmd="$path $python $T";
   //exec("$cmd",$output);
 //echo implode(",",$myArray);
  //echo $myArray;echo $output;
 //echo $output;
?>

