<?php
test_echo();
//	$T = $this->input->post('T');

  //$T=$_POST["T"];
 // $N=$_POST["N"]
 // $SurvivalTime=$_POST["SurvivalTime"]
 // $TumorSize=$_POST["TumorSize"]
 // $PrimarySitelabeled=$_POST["PrimarySite.labeled"]
 // $PrimarySite=$_POST["PrimarySite"]
 // $CSlymphnodes2004=$_POST["CSlymphnodes.2004.."]
 // $RXSummSurgOthRegDis2003=$_POST["RXSumm..SurgOthReg.Dis.2003.."]
 // $RXSummScopeRegLNSur2003=$_POST["RXSumm..ScopeRegLNSur.2003."]
 // $RXSummSurgPrimSite1998=$_POST["RXSumm..SurgPrimSite.1998.."]
 // $Reasonnocancerdirectedsurgery=$_POST["Reasonnocancer.directedsurgery"]
 // $DerivedSS1977=$_POST["DerivedSS1977"]
 // $SurvivalClass=$_POST["Survival Class"]
?>
<script>
	function test_echo () {
		$T = $this->input->post('T');
		echo $T;
	}

</script>
