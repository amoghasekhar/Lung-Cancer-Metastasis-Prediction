#!/usr/bin/env python3.5

# In[2]:
import sys
#print(sys.path)
import pandas as pd
import numpy  as np
#print("asdad")

#import pandas as pd
row=[]
#print(type(row))
a=sys.argv[1]
#print(row[0])
a1=sys.argv[2]
#print(row)

'''
parameter_dict = {}
for user_input in argv[1:]:
      parameter_dict[varname] = userinput
print(param_dict)
'''

b=sys.argv[3]
#print(b)
c=sys.argv[4]
#print(c)
d=sys.argv[5]
#print(d)
e=sys.argv[6]
#print(e)
f=sys.argv[7]
#print(f)
g=sys.argv[8]
#print(g)
h=sys.argv[9]
#print(h)
i=sys.argv[10]
#print(i)
j=sys.argv[11]
#print(j)
field=[]
field.append(a)
field.append(a1)
field.append(b)
field.append(c)
field.append(d)
field.append(e)
field.append(f)
field.append(g)
field.append(h)
field.append(i)
field.append(j)
#print(field)
row=[]
row=field
#print(row)
a=np.array(field)
#print(field[0])
#print(row[2])
fieldsused=[
       'T', 'N','SurvivalTime', 'TumorSize',
       'PrimarySite',
       'CSlymphnodes.2004..',
        'RXSumm..SurgOthReg.Dis.2003..',
       'RXSumm..ScopeRegLNSur.2003..', 'RXSumm..SurgPrimSite.1998..',
       'Reasonnocancer.directedsurgery', 'DerivedSS1977']
#df = pd.DataFrame([a],columns=fieldsused)
#out = np.empty(df.shape[0], dtype=object)

#out[:] = df.values.tolist()
# NOT HAPPENING PART

row[2]=float(row[2])
st= row[2]
new_st= (70-st)/70
row[2]= new_st

row[3]=int(row[3])       
ts= row[3]
new_ts= (999-ts)/999
row[3]= new_ts
        
#*********************************************************************************************************************
row[4]=int(row[4])
ps= row[4]
new_ps= (349-ps)/349
row[4]= new_ps
        
#*********************************************************************************************************************
row[5]=int(row[5])
ly= row[5]
new_ly= (800-ly)/(800)
row[5]= new_ly

row[8]=int(row[8])
rx= row[8]
new_rx= (99-rx)/99
row[8]= new_rx

if row[0]== 'Tis':
    row[0]= 1;
elif row[0]=='T1':
    row[0]= 0.2;
elif row[0]=='T2':
    row[0]= 0.4;
elif row[0]== 'T3':
    row[0]= 0.6;
elif row[0]== 'T4':
    row[0]= 0.8;
elif row[0]== 'T0':
    row[0]= 0;
#print(row);
#********************************************************************************************************************
if row[1]== 'N0':
    row[1]=0;
elif row[1]== 'N1':
    row[1]=0.333333333;
elif row[1]== 'N2':
    row[1]=0.666666667;
elif row[1]=='N3':
    row[1]=1;
            
#********************************************************************************************************************

        
#*********************************************************************************************************************

if row[6]== 'Nonediagnosedatautopsy':
    row[6]=0.833333333;
elif row[6]== 'Non-primarysurgicalproceduretootherregionalsites':
    row[6]=0.666666667;
elif row[6]=='Non-primarysurgicalprocedureperformed':
    row[6]=0.166666667;
elif row[6]== 'Unknowndeathcertificateonly':
    row[6]=1;
elif row[6]== 'Non-primarysurgicalproceduretodistantsite':
    row[6]=0.5;
elif row[6]== 'Anycomboofsurproctoothrgdislymndand/ordissite':
    row[6]=0;
elif row[6]== 'Non-primarysurgicalproceduretodistantlymphnode(s)':
    row[6]= 0.333333333;
        
        
#*******************************************************************************************************************
if row[7]== 'None':
    row[7]= 0.375;
elif row[7]== '1to3regionallymphnodesremoved':
    row[7]= 0;
elif row[7]== '4ormoreregionallymphnodesremoved':
    row[7]= 0.125;
elif row[7]== 'Numberofregionallymphnodesremovedunknown':
    row[7]= 0.5;
elif row[7]== 'BiopsyoraspirationofregionallymphnodeNOS':
    row[7]= 0.25;
elif row[7]== 'Unknownornotapplicable':
    row[7]= 1;
elif row[7]== 'Sentinelnodebiopsyandlymndremoveddifferenttimes':
    row[7]= 0.75;
elif row[7]== 'Sentinellymphnodebiopsy':
    row[7]= 0.625;
elif row[7]== 'Sentinelnodebiopsyandlymndremovedsame/unstatedtime':
    row[7]= 0.875;

#******************************************************************************************************************

        
#******************************************************************************************************************

if row[9]== 'Surgeryperformed':
    row[9]= 0.857142857;
elif row[9]== 'Notrecommended':
    row[9]=0.142857143;
elif row[9]== 'Recommendedbutnotperformedunknownreason':
    row[9]= 0.571428571;
elif row[9]== 'Notrecommendedcontraindicatedduetootherconditions':
    row[9]= 0.285714286;
elif row[9]== 'Notperformedpatientdiedpriortorecommendedsurgery':
    row[9]= 0;
elif row[9]== 'Recommendedbutnotperformedpatientrefused':
    row[9]= 0.428571429;
elif row[9]== 'Recommendedunknownifperformed':
    row[9]= 0.714285714;
elif row[9]== 'Unknowndeathcertificateorautopsyonlycase':
    row[9]= 1;
            
#*******************************************************************************************************************
if row[10]== 'IS':
    row[10]= 0.0;
elif row[10]== 'L':
    row[10]= 0.2;
elif row[10]== 'RE':
    row[10]= 0.4;
elif row[10]== 'RN':
    row[10]= 0.6;
elif row[10]== 'D':
    row[10]= 1.0;
elif row[10]== 'RE+RN':
    row[10]= 0.8;
            
#print(row.head(3));
print("Log-\n\n")


print("Data before-\n")

print(a)
        
            
print("data after normalization-\n")

b = np.array(row)
print(b)
dfnew = pd.DataFrame([b],columns=fieldsused)
dfnew.to_csv('./testdata.csv',encoding='utf-8')
print("now training....")
#dftest=pd.read_csv('./testdata.csv',encoding='utf-8',usecols=fieldsused)
#print('open')
#print(dftest.head())
#print(dftest.columns)
#dfnew.to_csv('./testdata.csv',encoding='utf-8')

#print(df.head())

#out = np.empty(df.shape[0], dtype=object)

#out[:] = df.values.tolist()
#print(out)
#print(out[0])
#row=[]
#row=out[0]

'''
print(df.head())
for index,row in df.iterrows():
	if row['T']== 'Tis':
		df.loc[index,'T']= 1
	if row['T']== 'T1':
		df.loc[index,'T']= 0.2
	if row['T']== 'T2':
		df.loc[index,'T']= 0.4
	if row['T']== 'T3':
		df.loc[index,'T']= 0.6
	if row['T']== 'T4':
		df.loc[index,'T']= 0.8
	if row['T']== 'T0':
		df.loc[index,'T']= 0

	
	if row['N']== 'N0':
		df.loc[index,'N']= 0
	if row['N']== 'N1':
		df.loc[index,'N']= 0.333333
	if row['N']== 'N2':
		df.loc[index,'N']= 0.66667
	if row['N']== 'N3':
		df.loc[index,'N']= 1
for index,row in df.iterrows():
	print(type(row['SurvivalTime']))
	row['SurvivalTime']=int(row['SurvivalTime'])
	print(type(row['SurvivalTime']))
'''




        
#*********************************************************************************************************************
'''        
row[3]=int(row[3])       
ts= row[3];
new_ts= (999-ts)/999;
row[3]= new_ts;
        
#*********************************************************************************************************************
row[4]=int(row[4])
ps= row[4];
new_ps= (349-ps)/9;
row[4]= new_ps;
        
#*********************************************************************************************************************
row[5]=int(row[5])
ly= row[5];
new_ly= (800-ly)/(800);
row[5]= new_ly;
'''
'''
print(df.head())
dfnew.to_csv('./testdata.csv',encoding='utf-8')
print('done')
dfnew=pd.read_csv('./testdata.csv',encoding='utf-8')
print('open')
print(dfnew.head())
print(dfnew.columns())
'''

