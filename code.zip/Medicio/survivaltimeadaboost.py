'''
import pandas as pd
import csv
import numpy as np
'''
'''
import sys
field=[]
#field[0]=sys.argv[1]
#field[1]=sys.argv[2]
for i in range(11):
      field[i]=sys.argv[i+1]
print(field)
'''
'''
import sys

a = np.array(['T4','N0',37,999,340,0,'Nonediagnosedatautopsy','None',23,'Surgeryperformed','IS'])
fieldsused=[
       'T', 'N','SurvivalTime', 'TumorSize',
       'PrimarySite',
       'CSlymphnodes.2004..',
        'RXSumm..SurgOthReg.Dis.2003..',
       'RXSumm..ScopeRegLNSur.2003..', 'RXSumm..SurgPrimSite.1998..',
       'Reasonnocancer.directedsurgery', 'DerivedSS1977']
df = pd.DataFrame([a],columns=fieldsused)
#print (df)
out = np.empty(df.shape[0], dtype=object)

out[:] = df.values.tolist()
#print(out)
#print(out[0])
row=[]
row=out[0]
#print(row)
#print(row[0])
#row= pd.read_csv('./data/LungCancerDataset_AllRecords.csv',nrows=5)
#print(row.head(3))
'''
'''
for index,row in df.iterrows():
      if row['T']== 'Tis':
            df.loc[index,'T']= 1
      if row['T']== 'T1':
            df.loc[index,'T']= 0.2
      if row['T']== 'T2':
            df.loc[index,'T']= 0.4
      if row['T']== 'T3':
            df.loc[index,'T']= 0.6
      if row['T']== 'T4':
            df.loc[index,'T']= 0.8

      if row['T']== 'T0':
            df.loc[index,'T']= 0

      if row['N']== 'Tis':
            df.loc[index,'T']= 1
      if row['N']== 'T1':
            df.loc[index,'T']= 0.2
      if row['N']== 'T2':
            df.loc[index,'T']= 0.4
      if row['N']== 'T3':
            df.loc[index,'T']= 0.6
      if row['N']== 'T4':
            df.loc[index,'T']= 0.8

      if row['T']== 'T0':
            df.loc[index,'T']= 0
print(df)
#print(row);
'''
'''
if row[0]== 'Tis':
    row[0]= 1;
elif row[0]=='T1':
    row[0]= 0.2;
elif row[0]=='T2':
    row[0]= 0.4;
elif row[0]== 'T3':
    row[0]= 0.6;
elif row[0]== 'T4':
    row[0]= 0.8;
elif row[0]== 'T0':
    row[0]= 0;
#print(row);
#********************************************************************************************************************
if row[1]== 'N0':
    row[1]=0;
elif row[1]== 'N1':
    row[1]=0.333333333;
elif row[1]== 'N2':
    row[1]=0.666666667;
elif row[1]=='N3':
    row[1]=1;
            
#********************************************************************************************************************
row[2]=int(row[2])
st= row[2];
new_st= (70-st)/70;
row[2]= new_st;
        
#*********************************************************************************************************************
        
row[3]=int(row[3])       
ts= row[3];
new_ts= (999-ts)/999;
row[3]= new_ts;
        
#*********************************************************************************************************************
row[4]=int(row[4])
ps= row[4];
new_ps= (349-ps)/9;
row[4]= new_ps;
        
#*********************************************************************************************************************
row[5]=int(row[5])
ly= row[5];
new_ly= (800-ly)/(800);
row[5]= new_ly;
        
#*********************************************************************************************************************

if row[6]== 'Nonediagnosedatautopsy':
    row[6]=0.833333333;
elif row[6]== 'Non-primarysurgicalproceduretootherregionalsites':
    row[6]=0.666666667;
elif row[6]=='Non-primarysurgicalprocedureperformed':
    row[6]=0.166666667;
elif row[6]== 'Unknowndeathcertificateonly':
    row[6]=1;
elif row[6]== 'Non-primarysurgicalproceduretodistantsite':
    row[6]=0.5;
elif row[6]== 'Anycomboofsurproctoothrgdislymndand/ordissite':
    row[6]=0;
elif row[6]== 'Non-primarysurgicalproceduretodistantlymphnode(s)':
    row[6]= 0.333333333;
        
        
#*******************************************************************************************************************
if row[7]== 'None':
    row[7]= 0.375;
elif row[7]== '1to3regionallymphnodesremoved':
    row[7]= 0;
elif row[7]== '4ormoreregionallymphnodesremoved':
    row[7]= 0.125;
elif row[7]== 'Numberofregionallymphnodesremovedunknown':
    row[7]= 0.5;
elif row[7]== 'BiopsyoraspirationofregionallymphnodeNOS':
    row[7]= 0.25;
elif row[7]== 'Unknownornotapplicable':
    row[7]= 1;
elif row[7]== 'Sentinelnodebiopsyandlymndremoveddifferenttimes':
    row[7]= 0.75;
elif row[7]== 'Sentinellymphnodebiopsy':
    row[7]= 0.625;
elif row[7]== 'Sentinelnodebiopsyandlymndremovedsame/unstatedtime':
    row[7]= 0.875;

#******************************************************************************************************************
row[8]=int(row[8])
rx= row[8];
new_rx= (99-rx)/99;
row[8]= new_rx;
        
#******************************************************************************************************************

if row[9]== 'Surgeryperformed':
    row[9]= 0.857142857;
elif row[9]== 'Notrecommended':
    row[9]=0.142857143;
elif row[9]== 'Recommendedbutnotperformedunknownreason':
    row[9]= 0.571428571;
elif row[9]== 'Notrecommendedcontraindicatedduetootherconditions':
    row[9]= 0.285714286;
elif row[9]== 'Notperformedpatientdiedpriortorecommendedsurgery':
    row[9]= 0;
elif row[9]== 'Recommendedbutnotperformedpatientrefused':
    row[9]= 0.428571429;
elif row[9]== 'Recommendedunknownifperformed':
    row[9]= 0.714285714;
elif row[9]== 'Unknowndeathcertificateorautopsyonlycase':
    row[9]= 1;
            
#*******************************************************************************************************************
if row[10]== 'IS':
    row[10]= 0.2;
elif row[10]== 'L':
    row[10]= 0.4;
elif row[10]== 'RE':
    row[10]= 0.6;
elif row[10]== 'RN':
    row[10]= 1;
elif row[10]== 'D':
    row[10]= 0;
elif row[10]== 'RE+RN':
    row[10]= 0.8;
            
#print(row.head(3));
        
            

print(row)
b = np.array(row)

dfnew = pd.DataFrame([b],columns=fieldsused)
#print(dfnew)
dfnew.to_csv('/home/vedanth/Downloads/lung-cancer-metastasis-prediction-master/data/testdata.csv',encoding='utf-8')

'''





import pandas as pd
import numpy as np
fieldsused=['Age', 'Grade', 'Radiationsequencewithsurgery', 'Numberofprimaries', 'SurvivalTime', 'TumorSize', 'Radiation',
       'BehaviorcodeICD.O.3', 'Yearofdiagnosis',
       'PrimarySite', 'HistologicTypeICD.O.3',
       'Firstmalignantprimaryindicator', 'Sequencenumber', 'ICD.O.3Hist.behavmalignant',
       'RXSumm..ScopeRegLNSur.2003..', 'RXSumm..SurgPrimSite.1998..',
       'Reasonnocancer.directedsurgery', 'SurvivalTimeClass',
       'Metastasis']
fieldsused1=[
       'T', 'N','SurvivalTime', 'TumorSize',
       'PrimarySite',
       'CSlymphnodes.2004..',
        'RXSumm..SurgOthReg.Dis.2003..',
       'RXSumm..ScopeRegLNSur.2003..', 'RXSumm..SurgPrimSite.1998..',
       'Reasonnocancer.directedsurgery', 'DerivedSS1977','Metastasis']
fieldsused2=[
       'T', 'N', 'TumorSize',
       'PrimarySite',
       'CSlymphnodes.2004..',
        'RXSumm..SurgOthReg.Dis.2003..',
       'RXSumm..ScopeRegLNSur.2003..', 'RXSumm..SurgPrimSite.1998..',
       'Reasonnocancer.directedsurgery', 'DerivedSS1977','SurvivalTimeClass']
data= pd.read_csv('/home/vedanth/Downloads/lung-cancer-metastasis-prediction-master/data/LungCancerDataset_AllRecords_NORM_reduced_features.csv',usecols=fieldsused1)
data.head(5)
#test_features1=[[0.2, 0, 0.4714285714285714, 0.0, 1.0, 1.0, 0.833333333, 0.375, 0.7676767676767676, 0.857142857, 0.2]]
test_features1=pd.read_csv('/var/www/html/Medicio/testdataST.csv',usecols=fieldsused2)
#print(test_features1.head())
new=test_features1.values.tolist()
#print(new)
import sys
#print(sys.argv[1])
#print("asda")
#print(sys.argv[2])

# In[3]:


#print('The shape of our features is', features.shape)


# In[4]:


#features.describe()


# In[5]:

#!/usr/bin/env python
# coding: utf-8

# In[8]:




# In[ ]:





# In[ ]:





# In[9]:


#X = normalizedData[:,0:18]
#Y = normalizedData[:,18]
from sklearn import model_selection
from sklearn.ensemble import AdaBoostRegressor
seed = 7
num_trees = 70


# In[10]:


labels= np.array(data['SurvivalTime'])
features= data.drop('SurvivalTime',axis=1)
feature_list= list(features.columns)
features= np.array(features)
#print(features)


# In[11]:


from sklearn.model_selection import train_test_split
# Split the data into training and testing sets
train_features, test_features, train_labels, test_labels = train_test_split(features, labels, test_size = 0.25, random_state = 42)


# In[7]:


#print('Training Features Shape:', train_features.shape)
#print('Training Labels Shape:', train_labels.shape)
#print('Testing Features Shape:', test_features.shape)
#print('Testing Labels Shape:', test_labels.shape)


# In[13]:


model = AdaBoostRegressor(n_estimators=num_trees, random_state=seed)
model.fit(train_features, train_labels);
predictions = model.predict(test_features1)
predictions[0]=predictions[0]*70
predictions[0]=70-predictions[0]
print(predictions[0],'months')
#print(model.feature_importances_*100)

errors = abs(predictions - test_labels)
# Print out the mean absolute error (mae)
#print('Mean Absolute Error:', round(np.mean(errors), 2), 'months.')

#print('Training Accuracy: ', model.score(train_features, train_labels)*100, '%')
#print('Testing Accuracy: ', model.score(test_features, test_labels)*100, '%')

from sklearn.ensemble import RandomForestRegressor
rf = RandomForestRegressor(n_estimators = 1000, random_state = 42)
rf.fit(train_features, train_labels);


# In[8]:

'''
predictions1 = rf.predict(test_features1)
predictions1[0]=predictions1[0]*70
predictions1[0]=70-predictions1[0]
print(predictions1[0],'months')
'''
# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




